import { DashboardHeader } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { PerformanceChart } from "@/components/dashboard/performance-chart"
import { GradeDistribution } from "@/components/dashboard/grade-distribution"
import { SubjectPerformance } from "@/components/dashboard/subject-performance"
import { CorrelationChart } from "@/components/dashboard/correlation-chart"
import { StudyHoursChart } from "@/components/dashboard/study-hours-chart"
import { StudentTable } from "@/components/dashboard/student-table"
import { InsightsPanel } from "@/components/dashboard/insights-panel"

export default function StudentPerformanceDashboard() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 overflow-auto">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Stats Overview */}
            <section>
              <h2 className="text-lg font-semibold mb-4">Overview</h2>
              <StatsCards />
            </section>

            {/* Performance Trends */}
            <section>
              <h2 className="text-lg font-semibold mb-4">Performance Analysis</h2>
              <div className="grid gap-6 lg:grid-cols-2">
                <PerformanceChart />
                <GradeDistribution />
              </div>
            </section>

            {/* Subject & Correlation Analysis */}
            <section>
              <h2 className="text-lg font-semibold mb-4">Subject & Factor Analysis</h2>
              <div className="grid gap-6 lg:grid-cols-3">
                <SubjectPerformance />
                <CorrelationChart />
                <StudyHoursChart />
              </div>
            </section>

            {/* Insights */}
            <section>
              <InsightsPanel />
            </section>

            {/* Student Details Table */}
            <section>
              <StudentTable />
            </section>

            {/* Footer */}
            <footer className="text-center py-6 text-sm text-muted-foreground border-t border-border">
              <p>Student Performance Analytics Dashboard • Educational Data Analysis</p>
              <p className="mt-1">Built for analyzing and improving student outcomes through data-driven insights</p>
            </footer>
          </div>
        </main>
      </div>
    </div>
  )
}
