// Mock student performance data
export const students = [
  { id: 1, name: "Alice Johnson", grade: "A", score: 92, attendance: 98, subject: "Mathematics", gender: "Female", studyHours: 8 },
  { id: 2, name: "Bob Smith", grade: "B", score: 78, attendance: 85, subject: "Science", gender: "Male", studyHours: 5 },
  { id: 3, name: "Carol Davis", grade: "A", score: 95, attendance: 100, subject: "English", gender: "Female", studyHours: 9 },
  { id: 4, name: "David Wilson", grade: "C", score: 65, attendance: 72, subject: "Mathematics", gender: "Male", studyHours: 3 },
  { id: 5, name: "Eva Martinez", grade: "B", score: 82, attendance: 90, subject: "Science", gender: "Female", studyHours: 6 },
  { id: 6, name: "Frank Brown", grade: "A", score: 88, attendance: 95, subject: "History", gender: "Male", studyHours: 7 },
  { id: 7, name: "Grace Lee", grade: "B", score: 75, attendance: 88, subject: "English", gender: "Female", studyHours: 5 },
  { id: 8, name: "Henry Taylor", grade: "D", score: 58, attendance: 65, subject: "Mathematics", gender: "Male", studyHours: 2 },
  { id: 9, name: "Ivy Chen", grade: "A", score: 97, attendance: 99, subject: "Science", gender: "Female", studyHours: 10 },
  { id: 10, name: "Jack Anderson", grade: "C", score: 70, attendance: 78, subject: "History", gender: "Male", studyHours: 4 },
  { id: 11, name: "Katie White", grade: "B", score: 80, attendance: 92, subject: "English", gender: "Female", studyHours: 6 },
  { id: 12, name: "Liam Harris", grade: "F", score: 45, attendance: 55, subject: "Mathematics", gender: "Male", studyHours: 1 },
  { id: 13, name: "Mia Clark", grade: "A", score: 91, attendance: 96, subject: "Science", gender: "Female", studyHours: 8 },
  { id: 14, name: "Noah Lewis", grade: "B", score: 76, attendance: 84, subject: "History", gender: "Male", studyHours: 5 },
  { id: 15, name: "Olivia Hall", grade: "C", score: 68, attendance: 75, subject: "English", gender: "Female", studyHours: 4 },
  { id: 16, name: "Paul Young", grade: "A", score: 89, attendance: 94, subject: "Mathematics", gender: "Male", studyHours: 7 },
  { id: 17, name: "Quinn King", grade: "B", score: 81, attendance: 89, subject: "Science", gender: "Female", studyHours: 6 },
  { id: 18, name: "Ryan Scott", grade: "D", score: 52, attendance: 60, subject: "History", gender: "Male", studyHours: 2 },
  { id: 19, name: "Sophia Adams", grade: "A", score: 94, attendance: 98, subject: "English", gender: "Female", studyHours: 9 },
  { id: 20, name: "Thomas Baker", grade: "C", score: 72, attendance: 80, subject: "Mathematics", gender: "Male", studyHours: 4 },
]

export const monthlyPerformance = [
  { month: "Jan", avgScore: 72, attendance: 85 },
  { month: "Feb", avgScore: 74, attendance: 87 },
  { month: "Mar", avgScore: 78, attendance: 88 },
  { month: "Apr", avgScore: 76, attendance: 86 },
  { month: "May", avgScore: 80, attendance: 90 },
  { month: "Jun", avgScore: 82, attendance: 91 },
  { month: "Jul", avgScore: 79, attendance: 88 },
  { month: "Aug", avgScore: 81, attendance: 89 },
  { month: "Sep", avgScore: 83, attendance: 92 },
  { month: "Oct", avgScore: 85, attendance: 93 },
  { month: "Nov", avgScore: 84, attendance: 91 },
  { month: "Dec", avgScore: 86, attendance: 94 },
]

export const gradeDistribution = [
  { grade: "A", count: 7, fill: "var(--color-a)" },
  { grade: "B", count: 6, fill: "var(--color-b)" },
  { grade: "C", count: 4, fill: "var(--color-c)" },
  { grade: "D", count: 2, fill: "var(--color-d)" },
  { grade: "F", count: 1, fill: "var(--color-f)" },
]

export const subjectPerformance = [
  { subject: "Mathematics", avgScore: 71, students: 5 },
  { subject: "Science", avgScore: 85, students: 5 },
  { subject: "English", avgScore: 80, students: 5 },
  { subject: "History", avgScore: 75, students: 5 },
]

export const studyHoursVsScore = students.map(s => ({
  name: s.name,
  studyHours: s.studyHours,
  score: s.score,
}))

export const genderDistribution = [
  { gender: "Male", count: 10, avgScore: 70.5, fill: "var(--color-male)" },
  { gender: "Female", count: 10, avgScore: 85.3, fill: "var(--color-female)" },
]

export const attendanceVsPerformance = students.map(s => ({
  name: s.name,
  attendance: s.attendance,
  score: s.score,
}))
