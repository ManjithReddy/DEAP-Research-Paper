"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, GraduationCap, TrendingUp, Award } from "lucide-react"
import { students } from "@/lib/student-data"

export function StatsCards() {
  const totalStudents = students.length
  const avgScore = Math.round(students.reduce((acc, s) => acc + s.score, 0) / totalStudents)
  const avgAttendance = Math.round(students.reduce((acc, s) => acc + s.attendance, 0) / totalStudents)
  const passRate = Math.round((students.filter(s => s.score >= 60).length / totalStudents) * 100)

  const stats = [
    {
      title: "Total Students",
      value: totalStudents,
      description: "Enrolled in program",
      icon: Users,
      trend: "+12% from last semester",
    },
    {
      title: "Average Score",
      value: `${avgScore}%`,
      description: "Across all subjects",
      icon: GraduationCap,
      trend: "+5% improvement",
    },
    {
      title: "Attendance Rate",
      value: `${avgAttendance}%`,
      description: "Overall attendance",
      icon: TrendingUp,
      trend: "+3% from last month",
    },
    {
      title: "Pass Rate",
      value: `${passRate}%`,
      description: "Students passing",
      icon: Award,
      trend: "Above target of 85%",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.title} className="border-border/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {stat.title}
            </CardTitle>
            <stat.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stat.trend}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
