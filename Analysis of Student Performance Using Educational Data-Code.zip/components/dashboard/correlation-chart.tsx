"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, ZAxis } from "recharts"
import { attendanceVsPerformance } from "@/lib/student-data"

export function CorrelationChart() {
  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle>Attendance vs Performance</CardTitle>
        <CardDescription>
          Correlation between student attendance and their scores
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                type="number" 
                dataKey="attendance" 
                name="Attendance"
                unit="%"
                domain={[50, 100]}
                className="text-xs fill-muted-foreground"
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                type="number" 
                dataKey="score" 
                name="Score"
                unit="%"
                domain={[40, 100]}
                className="text-xs fill-muted-foreground"
                tickLine={false}
                axisLine={false}
              />
              <ZAxis range={[60, 60]} />
              <Tooltip 
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
                formatter={(value: number, name: string) => [`${value}%`, name]}
              />
              <Scatter 
                name="Students" 
                data={attendanceVsPerformance} 
                fill="hsl(var(--primary))"
              />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
        <p className="text-sm text-muted-foreground text-center mt-2">
          Strong positive correlation: Higher attendance leads to better performance
        </p>
      </CardContent>
    </Card>
  )
}
