"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Lightbulb, Target } from "lucide-react"
import { students } from "@/lib/student-data"

export function InsightsPanel() {
  const topPerformers = students.filter(s => s.score >= 90).length
  const atRisk = students.filter(s => s.score < 60).length
  const avgStudyHours = (students.reduce((acc, s) => acc + s.studyHours, 0) / students.length).toFixed(1)

  const insights = [
    {
      icon: TrendingUp,
      title: "Top Performers",
      description: `${topPerformers} students (${Math.round((topPerformers / students.length) * 100)}%) scoring above 90%`,
      color: "text-green-600 dark:text-green-400",
      bgColor: "bg-green-100 dark:bg-green-900/30",
    },
    {
      icon: AlertTriangle,
      title: "At-Risk Students",
      description: `${atRisk} students need immediate academic intervention`,
      color: "text-red-600 dark:text-red-400",
      bgColor: "bg-red-100 dark:bg-red-900/30",
    },
    {
      icon: Target,
      title: "Study Impact",
      description: `Average ${avgStudyHours} study hours/day correlates with success`,
      color: "text-blue-600 dark:text-blue-400",
      bgColor: "bg-blue-100 dark:bg-blue-900/30",
    },
    {
      icon: CheckCircle,
      title: "Attendance Effect",
      description: "Students with 90%+ attendance average 15% higher scores",
      color: "text-emerald-600 dark:text-emerald-400",
      bgColor: "bg-emerald-100 dark:bg-emerald-900/30",
    },
    {
      icon: Lightbulb,
      title: "Key Finding",
      description: "Female students outperform by 15% on average in this dataset",
      color: "text-amber-600 dark:text-amber-400",
      bgColor: "bg-amber-100 dark:bg-amber-900/30",
    },
    {
      icon: TrendingDown,
      title: "Area of Concern",
      description: "Mathematics shows lowest average score at 71%",
      color: "text-orange-600 dark:text-orange-400",
      bgColor: "bg-orange-100 dark:bg-orange-900/30",
    },
  ]

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle>Key Insights & Analytics</CardTitle>
        <CardDescription>
          Data-driven observations from student performance analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {insights.map((insight, index) => (
            <div 
              key={index}
              className="flex items-start gap-3 p-4 rounded-lg border border-border/50 hover:border-border transition-colors"
            >
              <div className={`p-2 rounded-lg ${insight.bgColor}`}>
                <insight.icon className={`h-4 w-4 ${insight.color}`} />
              </div>
              <div>
                <h4 className="font-medium text-sm">{insight.title}</h4>
                <p className="text-xs text-muted-foreground mt-1">{insight.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
