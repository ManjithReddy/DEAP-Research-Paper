"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { students } from "@/lib/student-data"

function getGradeBadgeVariant(grade: string) {
  switch (grade) {
    case "A":
      return "default"
    case "B":
      return "secondary"
    case "C":
      return "outline"
    case "D":
      return "outline"
    case "F":
      return "destructive"
    default:
      return "outline"
  }
}

function getScoreColor(score: number) {
  if (score >= 90) return "text-green-600 dark:text-green-400"
  if (score >= 80) return "text-blue-600 dark:text-blue-400"
  if (score >= 70) return "text-yellow-600 dark:text-yellow-400"
  if (score >= 60) return "text-orange-600 dark:text-orange-400"
  return "text-red-600 dark:text-red-400"
}

export function StudentTable() {
  const sortedStudents = [...students].sort((a, b) => b.score - a.score)

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle>Student Performance Details</CardTitle>
        <CardDescription>
          Individual student scores, attendance, and study metrics
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-2 font-medium text-muted-foreground">Rank</th>
                <th className="text-left py-3 px-2 font-medium text-muted-foreground">Name</th>
                <th className="text-left py-3 px-2 font-medium text-muted-foreground">Subject</th>
                <th className="text-center py-3 px-2 font-medium text-muted-foreground">Grade</th>
                <th className="text-right py-3 px-2 font-medium text-muted-foreground">Score</th>
                <th className="text-right py-3 px-2 font-medium text-muted-foreground">Attendance</th>
                <th className="text-right py-3 px-2 font-medium text-muted-foreground">Study Hrs</th>
              </tr>
            </thead>
            <tbody>
              {sortedStudents.map((student, index) => (
                <tr key={student.id} className="border-b border-border/50 hover:bg-muted/50 transition-colors">
                  <td className="py-3 px-2 font-medium">{index + 1}</td>
                  <td className="py-3 px-2">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium text-xs">
                        {student.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <span className="font-medium">{student.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-2 text-muted-foreground">{student.subject}</td>
                  <td className="py-3 px-2 text-center">
                    <Badge variant={getGradeBadgeVariant(student.grade)}>
                      {student.grade}
                    </Badge>
                  </td>
                  <td className={`py-3 px-2 text-right font-semibold ${getScoreColor(student.score)}`}>
                    {student.score}%
                  </td>
                  <td className="py-3 px-2 text-right text-muted-foreground">{student.attendance}%</td>
                  <td className="py-3 px-2 text-right text-muted-foreground">{student.studyHours}h</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
