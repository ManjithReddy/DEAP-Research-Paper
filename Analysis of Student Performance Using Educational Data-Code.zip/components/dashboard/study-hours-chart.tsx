"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, ZAxis } from "recharts"
import { studyHoursVsScore } from "@/lib/student-data"

export function StudyHoursChart() {
  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle>Study Hours vs Performance</CardTitle>
        <CardDescription>
          Impact of study hours on student scores
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                type="number" 
                dataKey="studyHours" 
                name="Study Hours"
                unit=" hrs"
                domain={[0, 12]}
                className="text-xs fill-muted-foreground"
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                type="number" 
                dataKey="score" 
                name="Score"
                unit="%"
                domain={[40, 100]}
                className="text-xs fill-muted-foreground"
                tickLine={false}
                axisLine={false}
              />
              <ZAxis range={[60, 60]} />
              <Tooltip 
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Scatter 
                name="Students" 
                data={studyHoursVsScore} 
                fill="hsl(var(--chart-2))"
              />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
        <p className="text-sm text-muted-foreground text-center mt-2">
          More study hours strongly correlate with higher academic performance
        </p>
      </CardContent>
    </Card>
  )
}
