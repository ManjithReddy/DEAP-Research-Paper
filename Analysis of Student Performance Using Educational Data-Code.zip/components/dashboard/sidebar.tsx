"use client"

import { cn } from "@/lib/utils"
import { 
  LayoutDashboard, 
  Users, 
  BarChart3, 
  BookOpen, 
  Settings,
  TrendingUp,
  FileText,
  Bell
} from "lucide-react"
import { Button } from "@/components/ui/button"

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: Users, label: "Students" },
  { icon: BarChart3, label: "Analytics" },
  { icon: BookOpen, label: "Courses" },
  { icon: TrendingUp, label: "Reports" },
  { icon: FileText, label: "Assessments" },
  { icon: Bell, label: "Notifications" },
  { icon: Settings, label: "Settings" },
]

export function Sidebar() {
  return (
    <aside className="hidden lg:flex w-64 flex-col border-r border-border bg-card">
      <nav className="flex-1 p-4 space-y-1">
        {menuItems.map((item) => (
          <Button
            key={item.label}
            variant={item.active ? "secondary" : "ghost"}
            className={cn(
              "w-full justify-start gap-3",
              item.active && "bg-primary/10 text-primary hover:bg-primary/20"
            )}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </Button>
        ))}
      </nav>
      <div className="p-4 border-t border-border">
        <div className="rounded-lg bg-muted/50 p-4">
          <h4 className="text-sm font-medium">Need Help?</h4>
          <p className="text-xs text-muted-foreground mt-1">
            Check our documentation for guides on using the analytics dashboard.
          </p>
          <Button variant="outline" size="sm" className="w-full mt-3">
            View Docs
          </Button>
        </div>
      </div>
    </aside>
  )
}
